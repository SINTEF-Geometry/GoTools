//===========================================================================
// Copyright (C) 1998, 2000-2007, 2010, 2011 SINTEF ICT, Applied
// Mathematics, Norway.
//
// This file is part of GoTools
//
// This program is free software; you can redistribute it and/or          
// modify it under the terms of the GNU General Public License            
// as published by the Free Software Foundation version 2 of the License. 
//
// This program is distributed in the hope that it will be useful,        
// but WITHOUT ANY WARRANTY; without even the implied warranty of         
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
// GNU General Public License for more details.                           
//
// You should have received a copy of the GNU General Public License      
// along with this program; if not, see <http://www.gnu.org/licenses>
//
// Contact information: E-mail: tor.dokken@sintef.no                      
// SINTEF ICT, Department of Applied Mathematics,                         
// P.O. Box 124 Blindern,                                                 
// 0314 Oslo, Norway.                                                     
//
// Other licenses are also available for this software, notably licenses
// for:
// - Building commercial software.                                        
// - Building software whose source code you wish to keep private.        
//===========================================================================

#include "sisl-copyright.h"

/*
 *
 * $Id: s6line.c,v 1.1 1994-04-21 12:10:42 boh Exp $
 *
 */


#define S6LINE

#include "sislP.h"

#if defined(SISLNEEDPROTOTYPES)
void 
s6line(double epoint[])
#else
void s6line(epoint)
     double epoint[];
#endif
{
  printf("\n s6line: %f    %f    %f ",epoint[0],epoint[1],epoint[2]);
}
