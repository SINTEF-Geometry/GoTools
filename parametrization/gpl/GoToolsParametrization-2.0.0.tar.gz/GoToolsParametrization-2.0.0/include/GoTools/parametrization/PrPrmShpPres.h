//===========================================================================
// GoTools Parametrization - SINTEF Geometry Tools Parametrization library,
// version 2.0.0
//
// Copyright (C) 2000-2007, 2010 SINTEF ICT, Applied Mathematics, Norway.
//
// This program is free software; you can redistribute it and/or          
// modify it under the terms of the GNU General Public License            
// as published by the Free Software Foundation version 2 of the License. 
//
// This program is distributed in the hope that it will be useful,        
// but WITHOUT ANY WARRANTY; without even the implied warranty of         
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
// GNU General Public License for more details.                           
//
// You should have received a copy of the GNU General Public License      
// along with this program; if not, write to the Free Software            
// Foundation, Inc.,                                                      
// 59 Temple Place - Suite 330,                                           
// Boston, MA  02111-1307, USA.                                           
//
// Contact information: E-mail: tor.dokken@sintef.no                      
// SINTEF ICT, Department of Applied Mathematics,                         
// P.O. Box 124 Blindern,                                                 
// 0314 Oslo, Norway.                                                     
//
// Other licenses are also available for this software, notably licenses
// for:
// - Building commercial software.                                        
// - Building software whose source code you wish to keep private.        
//===========================================================================

#ifndef PRPRMSHPPRES_H
#define PRPRMSHPPRES_H

#include "GoTools/parametrization/PrParametrizeInt.h"

/*<PrPrmShpPres-syntax: */

/** PrPrmShpPres - Implement the shape-preserving parametrization
 * by implementing the virtual function makeWeights  
 */
class PrPrmShpPres : public PrParametrizeInt
{
protected:
  std::vector<double> u_;
  std::vector<double> v_;
  std::vector<double> alpha_;
  std::vector<double> len_;

  virtual bool makeWeights(int i);
  bool         localParam(int i);

public:
  /// Default constructor 
  PrPrmShpPres();
  /// Empty destructor
  virtual ~PrPrmShpPres();

};


/*>PrPrmShpPres-syntax: */

/*Class:PrPrmShpPres

Name:              PrPrmShpPres
Syntax:	           @PrPrmShpPres-syntax
Keywords:
Description:       Implement the shape-preserving parametrization
                   by implementing the virtual function makeWeights.
Member functions:
                   "attach(PrOrganizedPoints& graph)" --\\
                   Set the planar graph.

Constructors:
Files:
Example:
See also:
Developed by:      SINTEF Applied Mathematics, Oslo, Norway
Author:	           Michael Floater, SINTEF
Date:              Mar. 97
*/

#endif // PRPRMSHPPRES_H
