//===========================================================================
// GoTools Parametrization - SINTEF Geometry Tools Parametrization library,
// version 2.0.0
//
// Copyright (C) 2000-2007, 2010 SINTEF ICT, Applied Mathematics, Norway.
//
// This program is free software; you can redistribute it and/or          
// modify it under the terms of the GNU General Public License            
// as published by the Free Software Foundation version 2 of the License. 
//
// This program is distributed in the hope that it will be useful,        
// but WITHOUT ANY WARRANTY; without even the implied warranty of         
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
// GNU General Public License for more details.                           
//
// You should have received a copy of the GNU General Public License      
// along with this program; if not, write to the Free Software            
// Foundation, Inc.,                                                      
// 59 Temple Place - Suite 330,                                           
// Boston, MA  02111-1307, USA.                                           
//
// Contact information: E-mail: tor.dokken@sintef.no                      
// SINTEF ICT, Department of Applied Mathematics,                         
// P.O. Box 124 Blindern,                                                 
// 0314 Oslo, Norway.                                                     
//
// Other licenses are also available for this software, notably licenses
// for:
// - Building commercial software.                                        
// - Building software whose source code you wish to keep private.        
//===========================================================================

#include "GoTools/parametrization/PrNestedNode.h"
#include <iostream>

// MEMBER FUNCTIONS

//-----------------------------------------------------------------------------
void PrNestedNode::print(std::ostream& os)
//-----------------------------------------------------------------------------
{
    os << x() << ' ' << y() << ' ' << z() << ' ' << u_ << ' ' << v_
       << ' ' << level_ << std::endl;
    for(size_t i=0; i<tr_.size(); i++) os << tr_[i] << " ";
    os << std::endl;
}

//-----------------------------------------------------------------------------
void PrNestedNode::printXYZ(std::ostream& os)
//-----------------------------------------------------------------------------
{
    os << x() << ' ' << y() << ' ' << z() << std::endl;
}

//-----------------------------------------------------------------------------
void PrNestedNode::printUV(std::ostream& os)
//-----------------------------------------------------------------------------
{
    os << u_ << ' ' << v_ << std::endl;
}
