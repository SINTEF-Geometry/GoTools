//===========================================================================
// GoTools Intersections - SINTEF Geometry Tools Intersections library,
// version 2.0.0
//
// Copyright (C) 2000-2007, 2010 SINTEF ICT, Applied Mathematics, Norway.
//
// This program is free software; you can redistribute it and/or          
// modify it under the terms of the GNU General Public License            
// as published by the Free Software Foundation version 2 of the License. 
//
// This program is distributed in the hope that it will be useful,        
// but WITHOUT ANY WARRANTY; without even the implied warranty of         
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
// GNU General Public License for more details.                           
//
// You should have received a copy of the GNU General Public License      
// along with this program; if not, write to the Free Software            
// Foundation, Inc.,                                                      
// 59 Temple Place - Suite 330,                                           
// Boston, MA  02111-1307, USA.                                           
//
// Contact information: E-mail: tor.dokken@sintef.no                      
// SINTEF ICT, Department of Applied Mathematics,                         
// P.O. Box 124 Blindern,                                                 
// 0314 Oslo, Norway.                                                     
//
// Other licenses are also available for this software, notably licenses
// for:
// - Building commercial software.                                        
// - Building software whose source code you wish to keep private.        
//===========================================================================

#ifndef _BOUNDARYGEOMINT_H
#define _BOUNDARYGEOMINT_H


#include <boost/shared_ptr.hpp>


namespace Go {


class ParamGeomInt;


/// This struct is a helper struct that bundles boundary information
/// for an object of type ParamGeomInt.

struct BoundaryGeomInt {

    boost::shared_ptr<ParamGeomInt> bd_obj_;
    int pardir_; // 2dim case: 0 || 1 (dir of par_, i.e. opp that of
		 // bd_obj_).
    double par_;

    /// Constructor
    /// \param bd_obj shared pointer to the object of interest
    /// \param dir parameter direction that specifies the boundary
    /// \param par the value of the relevant parameter at the boundary
    BoundaryGeomInt(boost::shared_ptr<ParamGeomInt> bd_obj,
		    int dir, double par)
    {
	bd_obj_ =  bd_obj;
	pardir_ = dir;
	par_ = par;
    }

    /// Destructor
    ~BoundaryGeomInt() { }

    /// Get the parameter direction that specifies the boundary
    /// \return the parameter direction
    int getDir()
    { return pardir_; }
     
    /// Get the value of the relevant parameter at the boundary
    /// \return the parameter value
    double getPar()
    { return par_; }

    /// Get the object which the boundary belongs to
    /// \return shared pointer to the object
    boost::shared_ptr<ParamGeomInt> getObject()
    { return bd_obj_; }
};


} // namespace Go


#endif // _BOUNDARYGEOMINT_H

