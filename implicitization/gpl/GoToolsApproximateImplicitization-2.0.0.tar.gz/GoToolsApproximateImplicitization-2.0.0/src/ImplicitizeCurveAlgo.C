//===========================================================================
// GoTools Approximate Implicitization - SINTEF Geometry Tools Approximate
// Implicitization library, version 2.0.0
//
// Copyright (C) 2000-2007, 2010 SINTEF ICT, Applied Mathematics, Norway.
//
// This program is free software; you can redistribute it and/or          
// modify it under the terms of the GNU General Public License            
// as published by the Free Software Foundation version 2 of the License. 
//
// This program is distributed in the hope that it will be useful,        
// but WITHOUT ANY WARRANTY; without even the implied warranty of         
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          
// GNU General Public License for more details.                           
//
// You should have received a copy of the GNU General Public License      
// along with this program; if not, write to the Free Software            
// Foundation, Inc.,                                                      
// 59 Temple Place - Suite 330,                                           
// Boston, MA  02111-1307, USA.                                           
//
// Contact information: E-mail: tor.dokken@sintef.no                      
// SINTEF ICT, Department of Applied Mathematics,                         
// P.O. Box 124 Blindern,                                                 
// 0314 Oslo, Norway.                                                     
//
// Other licenses are also available for this software, notably licenses
// for:
// - Building commercial software.                                        
// - Building software whose source code you wish to keep private.        
//===========================================================================

#include "GoTools/implicitization/ImplicitizeCurveAlgo.h"
#include "GoTools/implicitization/ImplicitUtils.h"
#include "GoTools/geometry/GeometryTools.h"


using namespace std;


namespace Go {


//==========================================================================
void ImplicitizeCurveAlgo::perform()
//==========================================================================
{
    // Create barycentric coordinate system
    create_bary_coord_system2D(curve_, bc_);

    // Convert spline curve to barycentric coordinates
    SplineCurve crv_bc;
    cart_to_bary(curve_, bc_, crv_bc);

    // Check if the curve has a single segment
    bool single_segment = (curve_.order() == curve_.numCoefs());

    // Make the matrix of numerical coefficients (the D-matrix). Any
    // vector in the nullspace of this matrix will be a solution.
    vector<vector<double> > mat;
    if (single_segment) {
	make_matrix(crv_bc, deg_, mat);
    } else {
	// The matrices from all the segments are stacked on top of each
	// other
	vector<SplineCurve> segments;
	splitCurveIntoSegments(crv_bc, segments);
	int num = segments.size();
	make_matrix(segments[0], deg_, mat);
	vector<vector<double> > tmp;
	for (int i = 1; i < num; ++i) {
	    make_matrix(segments[i], deg_, tmp);
	    mat.insert(mat.end(), tmp.begin(), tmp.end());
	}
    }

    // Find the nullspace and construct the implicit function.
    vector<double> b;
    make_implicit_gauss(mat, b);

    // We boldly assume there is no error for the Gaussian elimination
    sigma_min_ = 0.0;

    // Set the coefficients
    implicit_ = BernsteinTriangularPoly(deg_, b);

    return;
}


//==========================================================================


} // namespace Go
